#!/usr/bin/env bash
set -euo pipefail

BUCKET=${1:?'Usage: $0 BUCKET S3_GGUF_KEY [MODEL_NAME]'}
S3_KEY=${2:?'Usage: $0 BUCKET S3_GGUF_KEY [MODEL_NAME]'}
MODEL_NAME=${3:-biomedical-assistant}
GGUF_LOCAL=/tmp/model.gguf

ensure_cmd() {
  command -v "$1" >/dev/null 2>&1 || { echo "Missing required command: $1"; exit 1; }
}

get_token() {
  TOKEN=$(curl -s -X PUT "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 21600" || true)
}

get_metadata() {
  local path="$1"
  if [ -n "${TOKEN:-}" ]; then
    curl -s -H "X-aws-ec2-metadata-token: $TOKEN" "http://169.254.169.254/latest/meta-data/${path}"
  else
    curl -s "http://169.254.169.254/latest/meta-data/${path}"
  fi
}

cleanup_old_container() {
  if sudo docker ps -a --format '{{.Names}}' | grep -qx open-webui; then
    sudo docker rm -f open-webui >/dev/null 2>&1 || true
  fi
}

echo '=== STEP 0: Preconditions ==='
ensure_cmd curl
ensure_cmd sudo
if ! command -v aws >/dev/null 2>&1; then
  echo 'AWS CLI not found. Installing...'
  sudo yum install -y -q awscli
fi

if ! aws sts get-caller-identity >/dev/null 2>&1; then
  echo 'AWS credentials are not available on this EC2 instance.'
  echo 'Fix one of these before re-running:'
  echo '1) Attach an IAM role to the EC2 instance with at least s3:GetObject permission on the model/script bucket.'
  echo '2) Configure credentials with: aws configure'
  exit 1
fi

echo '=== STEP 1: Install Ollama ==='
if ! command -v ollama >/dev/null 2>&1; then
  curl -fsSL https://ollama.com/install.sh | sh
fi
pkill -f 'ollama serve' >/dev/null 2>&1 || true
nohup ollama serve > /tmp/ollama.log 2>&1 &
sleep 10
curl -sf http://localhost:11434/api/tags >/dev/null && echo 'Ollama is up' || { echo 'Ollama failed'; tail -n 50 /tmp/ollama.log || true; exit 1; }

echo '=== STEP 2: Download GGUF from S3 ==='
mkdir -p /tmp
aws s3 cp "s3://${BUCKET}/${S3_KEY}" "$GGUF_LOCAL"
echo "Downloaded: $(du -sh "$GGUF_LOCAL" | cut -f1)"

echo '=== STEP 3: Create Modelfile ==='
cat > /tmp/Modelfile <<EOF
FROM ${GGUF_LOCAL}
SYSTEM You are a biomedical research assistant specialized in summarizing and explaining medical research papers. You provide clear, accurate, and professional medical information based on published research abstracts. Always cite the study title when discussing findings.
PARAMETER temperature 0.3
PARAMETER top_p 0.9
PARAMETER top_k 40
PARAMETER num_predict 512
PARAMETER stop Human:
PARAMETER stop Assistant:
EOF

ollama create "$MODEL_NAME" -f /tmp/Modelfile
echo 'Loaded models:'
ollama list

echo '=== STEP 4: Test model ==='
sleep 3
curl -s http://localhost:11434/api/generate \
  -H 'Content-Type: application/json' \
  -d "{\"model\":\"${MODEL_NAME}\",\"prompt\":\"What is the mechanism of BRCA1 in DNA repair?\",\"stream\":false}" \
  | python3 -m json.tool

echo '=== STEP 5: Install Docker ==='
sudo yum update -y -q
sudo yum install -y -q docker
sudo systemctl enable docker
sudo systemctl start docker
sudo usermod -aG docker ec2-user || true
echo "Docker: $(docker --version)"

echo '=== STEP 6: Launch OpenWebUI ==='
cleanup_old_container
sudo docker run -d \
  --name open-webui \
  --restart always \
  -p 8080:8080 \
  --add-host=host.docker.internal:host-gateway \
  -e OLLAMA_BASE_URL=http://host.docker.internal:11434 \
  -v open-webui:/app/backend/data \
  ghcr.io/open-webui/open-webui:main

sleep 15
sudo docker ps | grep open-webui

get_token
PUBLIC_IP=$(get_metadata public-ipv4 || true)

echo ''
echo '=== SETUP COMPLETE ==='
echo "Ollama API : http://${PUBLIC_IP}:11434"
echo "OpenWebUI  : http://${PUBLIC_IP}:8080"