
## Phase 1 — Data Ingestion

**Goal:** Stream up to 1,000,000 PubMed records from HuggingFace and write them as
Snappy-compressed Parquet files to S3.

**Script:** `spark/download_pubmed.py`

---

### Step 1.1 — Verify S3 Bucket Exists

```bash
aws s3 ls s3://q1abc-cisc886-bucket/

# If it does not exist:
aws s3 mb s3://q1abc-cisc886-bucket --region us-east-1
```

---

### Step 1.2 — Install Ingestion Dependencies

```bash
pip install datasets pyarrow boto3 tqdm
```

---

### Step 1.3 — Run the Ingestion Script

```bash
python spark/download_pubmed.py \
  --bucket      q1abc-cisc886-bucket \
  --max_records 1000000 \
  --batch_size  10000
```

| Parameter        | Default                   | Description                                   |
|------------------|---------------------------|-----------------------------------------------|
| `--bucket`       | `q1abc-cisc886-bucket`    | Target S3 bucket name                         |
| `--max_records`  | `1000000`                 | Maximum number of PubMed records to ingest    |
| `--batch_size`   | `10000`                   | Records per Parquet batch / S3 file           |
| `--prefix`       | `raw/pubmed/`             | S3 key prefix for output files                |

---

### Step 1.4 — Verify Uploaded Files

```bash
aws s3 ls s3://q1abc-cisc886-bucket/raw/pubmed/ --human-readable --summarize
```

**Expected Output:**

```
2024-03-15 10:22:01   12.4 MiB raw/pubmed/batch_0000.parquet
2024-03-15 10:22:14   12.1 MiB raw/pubmed/batch_0001.parquet
...
2024-03-15 10:48:32   11.9 MiB raw/pubmed/batch_0099.parquet

Total Objects: 100
Total Size:    1.2 GiB
```

**Output Schema — Parquet Fields:**

| Field      | Type   | Description                         |
|------------|--------|-------------------------------------|
| `pmid`     | int64  | PubMed unique article identifier    |
| `title`    | string | Article title                       |
| `abstract` | string | Full abstract text                  |
| `year`     | int32  | Publication year                    |

> **Note:** Records with null or empty `abstract` fields are automatically skipped during
> ingestion. The HuggingFace streaming API is used to avoid downloading the full dataset locally.

---

## Phase 2 — Spark Preprocessing

**Goal:** Use Apache Spark on AWS EMR to clean, filter, and reformat the raw PubMed Parquet
files into an instruction-following dataset ready for fine-tuning.

**Script:** `spark/spark_preprocess.py`

---

### Step 2.1 — Launch an EMR Cluster

```bash
aws emr create-cluster \
  --name           "cisc886-pubmed-preprocessing" \
  --release-label  emr-6.15.0 \
  --applications   Name=Spark \
  --instance-type  m5.xlarge \
  --instance-count 3 \
  --use-default-roles \
  --region         us-east-1 \
  --log-uri        s3://q1abc-cisc886-bucket/emr-logs/
```

> **Note:** Record the returned `ClusterId` (e.g., `j-XXXXXXXXXX`) —
> you will need it in the following steps.

---

### Step 2.2 — Upload the Preprocessing Script to S3

```bash
aws s3 cp spark/spark_preprocess.py \
  s3://q1abc-cisc886-bucket/scripts/spark_preprocess.py
```

---

### Step 2.3 — Submit the Spark Job as an EMR Step

```bash
aws emr add-steps \
  --cluster-id j-XXXXXXXXXX \
  --steps Type=Spark,Name="PubMed Preprocessing",\
ActionOnFailure=CONTINUE,\
Args=[--deploy-mode,cluster,\
--master,yarn,\
s3://q1abc-cisc886-bucket/scripts/spark_preprocess.py,\
--input,s3://q1abc-cisc886-bucket/raw/pubmed/,\
--output,s3://q1abc-cisc886-bucket/processed/train/] \
  --region us-east-1
```

---

### Step 2.4 — Monitor Job Progress

```bash
aws emr describe-step \
  --cluster-id j-XXXXXXXXXX \
  --step-id    s-XXXXXXXXXX \
  --region     us-east-1 \
  --query      'Step.Status.State'
```

**Expected States:** `PENDING` -> `RUNNING` -> `COMPLETED`

---

### Step 2.5 — Preprocessing Transformations Applied

| Transformation              | Description                                                  |
|-----------------------------|--------------------------------------------------------------|
| Null / empty abstract drop  | Removes records where `abstract` is null or whitespace       |
| Short abstract filter       | Drops abstracts shorter than 50 characters                   |
| Year range filter           | Retains articles from year 1900 onwards                      |
| Instruction format wrapping | Wraps each record as `instruction` + `text` fields           |
| Deduplication               | Drops duplicate `pmid` values                                |
| Repartitioning              | Outputs 50 evenly-sized Parquet files                        |

**Output Schema:**

| Field         | Type   | Description                                          |
|---------------|--------|------------------------------------------------------|
| `instruction` | string | System prompt: "Summarize this biomedical abstract"  |
| `text`        | string | Concatenation of title + abstract                    |

---

### Step 2.6 — Verify Processed Output

```bash
aws s3 ls s3://q1abc-cisc886-bucket/processed/train/ --human-readable --summarize
```

---

### Step 2.7 — Terminate the EMR Cluster

```bash
aws emr terminate-clusters --cluster-ids j-XXXXXXXXXX --region us-east-1
```

> **Cost Warning:** EMR clusters accrue charges per node-hour. Always terminate the cluster
> immediately after the job completes. Use the `--auto-terminate` flag for one-off jobs.

---

## Phase 3 — Model Fine-Tuning

**Goal:** Fine-tune `TinyLlama-1.1B-Chat-v1.0` on the processed PubMed instruction dataset
using LoRA (PEFT) via the Unsloth framework in Google Colab, then export to GGUF q4_k_m
format and upload to S3.

**Notebook:** `finetuning/finetune_tinyllama.ipynb`  
**Training Platform:** Google Colab (GPU runtime — T4 or A100 recommended)

---

### Step 3.1 — Open the Notebook in Google Colab

Upload `finetuning/finetune_tinyllama.ipynb` via **File -> Upload notebook**, or use the
direct link:

```
https://colab.research.google.com/github/<your-org>/CloudProject-Team19/blob/main/finetuning/finetune_tinyllama.ipynb
```

---

### Step 3.2 — Enable GPU Runtime

```
Runtime -> Change runtime type -> Hardware accelerator -> GPU (T4 or A100)
```

---

### Step 3.3 — Install Dependencies

```bash
pip install "unsloth[colab-new] @ git+https://github.com/unslothai/unsloth.git"
pip install --no-deps trl peft accelerate bitsandbytes transformers datasets
pip install pyarrow boto3
```

---

### Step 3.4 — Configure AWS Credentials in Colab

```python
import os
os.environ["AWS_ACCESS_KEY_ID"]     = "YOUR_ACCESS_KEY"
os.environ["AWS_SECRET_ACCESS_KEY"] = "YOUR_SECRET_KEY"
os.environ["AWS_DEFAULT_REGION"]    = "us-east-1"
```

> **Security:** Use temporary session credentials or a scoped IAM role. Never hardcode
> long-term credentials in a notebook you intend to share or commit.

---

### Step 3.5 — Load Processed Data from S3

```python
import pyarrow.dataset as ds

dataset = ds.dataset(
    "s3://q1abc-cisc886-bucket/processed/train/",
    format="parquet"
)
table = dataset.to_table(columns=["instruction", "text"])
```

---

### Step 3.6 — Load Base Model with Unsloth

```python
from unsloth import FastLanguageModel

model, tokenizer = FastLanguageModel.from_pretrained(
    model_name     = "TinyLlama/TinyLlama-1.1B-Chat-v1.0",
    max_seq_length = 2048,
    dtype          = None,    # Auto-detect: float16 on T4, bfloat16 on A100
    load_in_4bit   = True,
)
```

---

### Step 3.7 — Apply LoRA Adapters

```python
model = FastLanguageModel.get_peft_model(
    model,
    r              = 16,
    target_modules = ["q_proj", "k_proj", "v_proj", "o_proj",
                      "gate_proj", "up_proj", "down_proj"],
    lora_alpha     = 16,
    lora_dropout   = 0.0,
    bias           = "none",
    use_gradient_checkpointing = True,
    random_state   = 42,
)
```

**LoRA Hyperparameter Reference:**

| Parameter                     | Value                     | Purpose                                             |
|-------------------------------|---------------------------|-----------------------------------------------------|
| `r` (rank)                    | 16                        | Controls adapter expressivity                       |
| `lora_alpha`                  | 16                        | Scaling factor (alpha/r = 1.0)                      |
| `lora_dropout`                | 0.0                       | Disabled — Unsloth recommendation for large data    |
| `bias`                        | `"none"`                  | No bias parameters trained                          |
| `target_modules`              | q/k/v/o + gate/up/down    | All attention + MLP projection layers               |
| `use_gradient_checkpointing`  | `True`                    | Reduces VRAM at cost of minor speed penalty         |
| `random_state`                | 42                        | Reproducibility seed                                |
| Trainable parameters          | 4,505,600 / 1,104,553,984 | 0.41% of total model parameters                     |

---

### Step 3.8 — Train with SFTTrainer (Chunked)

Training is performed in **chunks of 5,000 examples** to fit within Colab session limits:

```python
from trl import SFTTrainer
from transformers import TrainingArguments

trainer = SFTTrainer(
    model              = model,
    tokenizer          = tokenizer,
    train_dataset      = hf_chunk,           # 5,000-record HuggingFace Dataset slice
    dataset_text_field = "text",
    max_seq_length     = 2048,
    args = TrainingArguments(
        per_device_train_batch_size = 2,
        gradient_accumulation_steps = 4,
        warmup_steps                = 5,
        num_train_epochs            = 1,
        learning_rate               = 2e-4,
        fp16                        = True,   # Use bf16=True on A100
        logging_steps               = 10,
        output_dir                  = "/tmp/tinyllama-output",
        save_strategy               = "no",
        optim                       = "adamw_8bit",
        seed                        = 42,
    ),
)
trainer.train()
```

**Training Configuration Summary:**

| Parameter                   | Value                                    |
|-----------------------------|------------------------------------------|
| Base model                  | TinyLlama-1.1B-Chat-v1.0                 |
| LoRA framework              | Unsloth (2x faster than standard PEFT)   |
| Batch size per device       | 2                                        |
| Gradient accumulation steps | 4                                        |
| Effective batch size        | 8                                        |
| Epochs per chunk            | 1                                        |
| Chunk size                  | 5,000 examples                           |
| Learning rate               | 2e-4                                     |
| Optimizer                   | AdamW 8-bit                              |
| Precision                   | fp16 (T4) / bf16 (A100)                  |

---

### Step 3.9 — Export to GGUF and Upload to S3

```python
# Export quantized GGUF
model.save_pretrained_gguf(
    "/tmp/tinyllama-chat-q4km",
    tokenizer,
    quantization_method = "q4_k_m"
)

# Upload to S3
import boto3
s3 = boto3.client("s3")
s3.upload_file(
    "/tmp/tinyllama-chat-q4km/tinyllama-chat-q4km.gguf",
    "q1abc-cisc886-bucket",
    "fine-tuned-models/tinyllama-q4km.gguf",
)
print("Model uploaded to S3 successfully.")
```

**Expected Output:**

```
Model uploaded to S3 successfully.
# File size: approximately 668 MB (q4_k_m quantization of 1.1B model)
```

---

## Phase 4 — Infrastructure & Deployment

**Goal:** Use Terraform to provision AWS infrastructure, then bootstrap an EC2 instance with
Ollama and Open WebUI to serve the fine-tuned biomedical chatbot.

---

### Sub-phase 4A — Terraform Infrastructure Provisioning

**Directory:** `terraform/`

#### Step 4A.1 — Prepare Variables

```bash
cp terraform/terraform.tfvars.example terraform/terraform.tfvars

# Edit terraform.tfvars with your values:
#   aws_region = "us-east-1"
#   key_name   = "your-ec2-keypair-name"
#   my_ip      = "your.public.ip.address/32"
```

#### Step 4A.2 — Initialize Terraform

```bash
cd terraform/
terraform init
```

**Expected Output:**

```
Initializing the backend...
Initializing provider plugins...
- Finding hashicorp/aws versions matching "~> 5.0"...
- Installed hashicorp/aws v5.x.x
Terraform has been successfully initialized!
```

#### Step 4A.3 — Plan the Infrastructure

```bash
terraform plan -out=tfplan
```

Terraform will provision the following resources:

| Resource                | Details                                              |
|-------------------------|------------------------------------------------------|
| `aws_vpc`               | CIDR `10.0.0.0/16`, DNS hostnames enabled            |
| `aws_subnet`            | Public subnet in `us-east-1a`                        |
| `aws_security_group`    | Ingress: 22 (SSH), 11434 (Ollama), 8080 (WebUI)      |
| `aws_instance`          | m5.xlarge, Amazon Linux 2, 100 GB gp3 EBS            |
| `aws_eip`               | Elastic IP attached to EC2 instance                  |

#### Step 4A.4 — Apply the Infrastructure

```bash
terraform apply tfplan
```

**Expected Output:**

```
Apply complete! Resources: 8 added, 0 changed, 0 destroyed.

Outputs:
  ec2_public_ip = "3.xx.xx.xx"
  instance_id   = "i-0xxxxxxxxxxxxxxxxx"
```

> **Note:** Save the `ec2_public_ip` value — you will need it throughout Phase 4B.

---

### Sub-phase 4B — EC2 Bootstrap & Deployment

**Script:** `deployment/setup_ec2.sh`

#### Step 4B.1 — Copy Setup Script to EC2

```bash
EC2_IP="3.xx.xx.xx"    # Replace with your Terraform output

scp -i ~/.ssh/your-keypair.pem \
    deployment/setup_ec2.sh \
    ec2-user@${EC2_IP}:/home/ec2-user/setup_ec2.sh
```

#### Step 4B.2 — SSH into the Instance

```bash
ssh -i ~/.ssh/your-keypair.pem ec2-user@${EC2_IP}
```

#### Step 4B.3 — Run the Setup Script

```bash
chmod +x setup_ec2.sh
./setup_ec2.sh
```

The script executes the following steps automatically:

| Step | Action                        | Detail                                                          |
|------|-------------------------------|-----------------------------------------------------------------|
| 1    | System update                 | `sudo yum update -y`                                            |
| 2    | Install Ollama                | Official install script from `ollama.ai`                        |
| 3    | Start Ollama server           | `nohup ollama serve > /tmp/ollama.log 2>&1 &`                   |
| 4    | Download GGUF from S3         | `aws s3 cp s3://.../tinyllama-q4km.gguf /tmp/model.gguf`        |
| 5    | Create Modelfile              | Writes `/tmp/Modelfile` with system prompt & params             |
| 6    | Load model into Ollama        | `ollama create biomedical-assistant -f /tmp/Modelfile`          |
| 7    | Test Ollama API               | `curl http://localhost:11434/api/generate` health check         |
| 8    | Install Docker                | Amazon Linux 2 Docker via `amazon-linux-extras`                 |
| 9    | Start Docker service          | `sudo systemctl start docker`                                   |
| 10   | Launch Open WebUI container   | `docker run` with host network bridge to Ollama                 |

#### Step 4B.4 — Verify Ollama is Running

```bash
curl http://localhost:11434/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "model": "biomedical-assistant",
    "prompt": "What is the role of CRISPR in gene therapy?",
    "stream": false
  }'
```

**Expected Response:**

```json
{
  "model": "biomedical-assistant",
  "response": "CRISPR-Cas9 is a revolutionary gene editing technology...",
  "done": true
}
```

#### Step 4B.5 — Launch Open WebUI (Docker)

```bash
sudo docker run -d \
  --name  open-webui \
  --restart always \
  -p 8080:8080 \
  -e OLLAMA_BASE_URL=http://host.docker.internal:11434 \
  --add-host=host.docker.internal:host-gateway \
  ghcr.io/open-webui/open-webui:main
```

#### Step 4B.6 — Access the Web Interface

Open your browser and navigate to:

```
http://<EC2_PUBLIC_IP>:8080
```

Create an admin account on first launch, then select **`biomedical-assistant`** from the
model dropdown and start chatting.

---

### Sub-phase 4C — Teardown

When finished, destroy all AWS resources to avoid ongoing charges:

```bash
cd terraform/
terraform destroy
# Type 'yes' when prompted
```

**Expected Output:**

```
Destroy complete! Resources: 8 destroyed.
```

---

## Configuration Reference

### LoRA Hyperparameters

| Parameter                     | Value   | Rationale                                                    |
|-------------------------------|---------|--------------------------------------------------------------|
| `r` (rank)                    | 16      | Balanced expressivity vs. parameter count for 1.1B model     |
| `lora_alpha`                  | 16      | alpha/r = 1.0 — standard stable scaling                      |
| `lora_dropout`                | 0.0     | Unsloth recommends 0 for speed; dataset is large enough      |
| `learning_rate`               | 2e-4    | Standard LoRA LR; higher than full fine-tuning               |
| `warmup_steps`                | 5       | Short warmup for chunk-based training sessions               |
| `max_seq_length`              | 2048    | Covers nearly all PubMed abstracts                           |
| Input quantization            | 4-bit   | Load-in-4bit via bitsandbytes for Colab VRAM efficiency      |
| Output quantization           | q4_k_m  | Best quality/size tradeoff for GGUF deployment               |

---

### Ollama Modelfile Settings

| Setting        | Value                              | Effect                                                |
|----------------|------------------------------------|-------------------------------------------------------|
| `FROM`         | `/tmp/model.gguf`                  | Path to the quantized GGUF file                       |
| `SYSTEM`       | Biomedical research assistant...   | Sets assistant persona and domain focus               |
| `temperature`  | `0.3`                              | Deterministic, factual responses                      |
| `top_p`        | `0.9`                              | Nucleus sampling — filters low-probability tokens     |
| `top_k`        | `40`                               | Limits vocabulary pool per generation step            |
| `num_predict`  | `512`                              | Maximum tokens generated per response                 |
| `stop`         | `"Human:"`, `"Assistant:"`         | Prevents role-playing or conversation loops           |
| Model name     | `biomedical-assistant`             | Ollama API identifier                                 |

> **Note:** `temperature: 0.3` is intentionally low for a biomedical context to prioritize
> factual accuracy. Increase to `0.7` for more conversational responses.

---

## Cost Summary

All charges were covered by **AWS student credits**. The table below reflects estimated
real-world costs for reference:

| Service             | Resource                    | Usage Assumption            | Est. Monthly Cost  |
|---------------------|-----------------------------|-----------------------------|--------------------|
| EC2                 | m5.xlarge (4 vCPU, 16 GiB) | 730 hours (continuous)      | ~$140.16           |
| EBS                 | gp3, 100 GB                 | Attached to EC2             | ~$8.00             |
| S3 Storage          | ~5 GB (data + model)        | Standard storage class      | ~$0.12             |
| S3 Requests         | PUT/GET during pipeline     | ~10,000 requests            | ~$0.05             |
| EMR                 | 3x m5.xlarge, ~1 hour       | One-time preprocessing      | ~$0.58             |
| Data Transfer Out   | Minimal (API responses)     | Light usage                 | ~$0.01             |
| **Total Estimate**  |                             |                             | **~$148.92/month** |
| **Actual Cost**     | AWS student credits applied |                             | **$0.00**          |

> **Tip:** To minimize cost in production, use **auto-stop scheduling** or switch to
> **EC2 Spot Instances** (up to 90% savings) when uptime SLA is not critical.

---

## Troubleshooting

| Symptom                                        | Likely Cause                                              | Fix                                                                                         |
|------------------------------------------------|-----------------------------------------------------------|---------------------------------------------------------------------------------------------|
| `NoCredentialsError` in Python scripts         | AWS CLI not configured                                    | Run `aws configure` and enter valid credentials                                             |
| S3 `AccessDenied` on upload                    | IAM user lacks `s3:PutObject` permission                  | Attach `AmazonS3FullAccess` or a scoped S3 policy to your IAM user                          |
| EMR step stuck in `PENDING`                    | Cluster bootstrap still in progress                       | Wait 5-10 min; check EMR console for bootstrap action logs                                  |
| Colab crashes during training (OOM)            | GPU VRAM exceeded                                         | Reduce `per_device_train_batch_size` to 1 or switch to A100 runtime                        |
| `ollama: command not found` on EC2             | Ollama install script failed                              | Re-run `curl -fsSL https://ollama.ai/install.sh \| sh` manually                            |
| `connection refused` on port 11434             | Ollama server not running                                 | Run `nohup ollama serve > /tmp/ollama.log 2>&1 &` and check `/tmp/ollama.log`               |
| Open WebUI container exits immediately         | Docker not started or port conflict                       | Run `sudo systemctl start docker` and check `sudo docker logs open-webui`                   |
| `model not found` in Ollama API call           | Modelfile not loaded correctly                            | Re-run `ollama create biomedical-assistant -f /tmp/Modelfile` and verify with `ollama list` |
| GGUF download from S3 is very slow             | EC2 in different region than S3 bucket                    | Ensure both EC2 and S3 bucket are in `us-east-1`                                            |
| `terraform apply` fails on security group      | Your IP has changed since `terraform.tfvars` was written  | Update `my_ip` in `terraform.tfvars` and re-run `terraform apply`                          |
| WebUI page not loading at `EC2_IP:8080`        | Security group missing inbound rule for port 8080         | Verify Terraform security group config; ensure port 8080 is open for your IP                |
| HuggingFace streaming timeout                  | Network instability or HuggingFace rate limiting          | Add retry logic or reduce `--batch_size` in `download_pubmed.py`                            |

For extended troubleshooting, see [`docs/troubleshooting.md`](docs/troubleshooting.md).

---

## Acknowledgements

### Frameworks & Libraries

| Tool / Framework          | Version  | Role in Project                                               |
|---------------------------|----------|---------------------------------------------------------------|
| Apache Spark (PySpark)    | 3.x      | Large-scale data preprocessing on EMR                        |
| Unsloth                   | Latest   | 2x faster LoRA fine-tuning with memory optimization          |
| HuggingFace Transformers  | 4.x      | Model loading, tokenization, training utilities               |
| HuggingFace TRL           | Latest   | SFTTrainer for supervised fine-tuning                         |
| HuggingFace PEFT          | Latest   | Parameter-efficient fine-tuning (LoRA)                        |
| HuggingFace Datasets      | Latest   | Streaming PubMed dataset access                               |
| Ollama                    | 0.1.x+   | Local LLM serving in GGUF format                              |
| Open WebUI                | Latest   | Browser-based chat interface for Ollama models                |
| Terraform                 | 1.7.x+   | Infrastructure as Code — AWS provisioning                     |
| PyArrow                   | Latest   | Parquet read/write for data pipeline                          |
| bitsandbytes              | Latest   | 4-bit and 8-bit quantization support                          |
| Docker                    | 24.x+    | Containerized Open WebUI deployment                           |
| Google Colab              | —        | Free GPU environment for model training                       |

---

### Cloud Services

| Service  | Provider | Role                                                |
|----------|----------|-----------------------------------------------------|
| S3       | AWS      | Raw data, processed data, and GGUF model storage    |
| EC2      | AWS      | Inference server (Ollama + Open WebUI)              |
| EMR      | AWS      | Managed Spark cluster for data preprocessing        |

---

### Dataset

| Dataset     | Source                                                                  | License     | URL                                                                                    |
|-------------|-------------------------------------------------------------------------|-------------|----------------------------------------------------------------------------------------|
| ncbi/pubmed | National Center for Biotechnology Information (NCBI) via HuggingFace   | Open Access | [huggingface.co/datasets/ncbi/pubmed](https://huggingface.co/datasets/ncbi/pubmed)    |

---

### Base Model

| Model                    | Organization | License    | URL                                                                                               |
|--------------------------|--------------|------------|---------------------------------------------------------------------------------------------------|
| TinyLlama-1.1B-Chat-v1.0 | TinyLlama    | Apache 2.0 | [huggingface.co/TinyLlama/TinyLlama-1.1B-Chat-v1.0](https://huggingface.co/TinyLlama/TinyLlama-1.1B-Chat-v1.0) |

---

<div align="center">

Made with dedication by **Team 19** — CISC 886 Cloud Computing  
Queen's University · 2026

</div>
```