#!/usr/bin/env python3
import argparse, io, time
import boto3
import pyarrow as pa
import pyarrow.parquet as pq
from datasets import load_dataset

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--bucket", required=True)
    p.add_argument("--limit", type=int, default=1000000)
    p.add_argument("--batch-size", type=int, default=10000)
    p.add_argument("--prefix", default="raw/pubmed")
    return p.parse_args()

def extract_fields(record):
    mc = record.get("MedlineCitation", {}) or {}
    article = mc.get("Article", {}) or {}
    journal = article.get("Journal", {}) or {}
    issue = journal.get("JournalIssue", {}) or {}
    pubdate = issue.get("PubDate", {}) or {}
    abstractblock = article.get("Abstract", {}) or {}
    abstracttext = abstractblock.get("AbstractText", "") or ""
    if isinstance(abstracttext, list):
        abstracttext = " ".join(t if isinstance(t, str) else t.get("#text", "") for t in abstracttext)
    pmidval = mc.get("PMID", "")
    pmid = pmidval.get("#text", "") if isinstance(pmidval, dict) else str(pmidval)
    return {
        "pmid": pmid,
        "title": str(article.get("ArticleTitle", "") or ""),
        "abstract": str(abstracttext),
        "year": str(pubdate.get("Year", "0000") or "0000"),
    }

def upload_batch(s3, bucket, prefix, batchnum, rows):
    table = pa.table({
        "pmid":     pa.array([r["pmid"]     for r in rows], type=pa.string()),
        "title":    pa.array([r["title"]    for r in rows], type=pa.string()),
        "abstract": pa.array([r["abstract"] for r in rows], type=pa.string()),
        "year":     pa.array([r["year"]     for r in rows], type=pa.string()),
    })
    buf = io.BytesIO()
    pq.write_table(table, buf, compression="snappy")
    key = f"{prefix}/batch{batchnum:05d}.parquet"
    s3.put_object(Bucket=bucket, Key=key, Body=buf.getvalue())
    print(f"  batch {batchnum:05d}  {len(rows)} records s3://{bucket}/{key}")

def main():
    args = parse_args()
    s3 = boto3.client("s3")
    print(f"Loading ncbi/pubmed streaming limit={args.limit}")
    ds = load_dataset("ncbi/pubmed", split="train", streaming=True, trust_remote_code=True)
    batch, batchnum, total = [], 0, 0
    t0 = time.time()
    for raw in ds:
        batch.append(extract_fields(raw))
        total += 1
        if len(batch) == args.batch_size:
            upload_batch(s3, args.bucket, args.prefix, batchnum, batch)
            batchnum += 1
            batch = []
            elapsed = time.time() - t0
            rate = total / elapsed
            eta_min = (args.limit - total) / rate / 60
            print(f"  progress {total}/{args.limit} {rate:.0f} recs/s ETA {eta_min:.1f} min")
        if total >= args.limit:
            break
    if batch:
        upload_batch(s3, args.bucket, args.prefix, batchnum, batch)
    print(f"Done! {total} records in {(time.time()-t0)/60:.1f} min")

if __name__ == "__main__":
    main()
PYEOF

