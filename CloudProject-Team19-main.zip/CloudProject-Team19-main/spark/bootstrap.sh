#!/bin/bash
sudo python3 -m pip install matplotlib boto3 --ignore-installed
