#!/usr/bin/env python3
import argparse, json, os, re
import boto3
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StringType

SPECIALTIES = {
    "Oncology":      r"cancer|tumor|carcinom|oncol|malignant|metasta",
    "Cardiology":    r"cardiac|heart|coronary|myocard|atrial|ventricula|cardio",
    "Neurology":     r"neuro|brain|stroke|alzheimer|parkinson|epilep|neural|cognitive",
    "Infectious":    r"virus|bacteria|infection|COVID|SARS|HIV|antibiotic|pathogen",
    "Immunology":    r"immune|antibody|autoimmune|lymphocyte|cytokine|immunother",
    "Genetics":      r"gene|DNA|RNA|mutation|genome|sequenc|CRISPR|variant",
    "Pharmacology":  r"drug|pharmacol|clinical trial|randomized|placebo|therapeut",
    "Psychiatry":    r"depress|anxiety|schizophren|bipolar|mental health|psychia",
    "Pulmonology":   r"lung|pulmon|asthma|COPD|respiratory|bronch",
    "Endocrinology": r"diabetes|insulin|thyroid|hormone|endocrin|metabol",
}

def classify(text):
    if not text:
        return "Other"
    for spec, pattern in SPECIALTIES.items():
        if re.search(pattern, text, re.IGNORECASE):
            return spec
    return "Other"

def build_instruction(title, abstract, spec):
    if not title or not abstract:
        return None
    return (f"Human: I am a medical professional. Please explain the following study: {title}\n"
            f"Assistant: [{spec}] {abstract}")

def fig1_wordcount(stats, outdir):
    order = ["<50","50-99","100-149","150-199","200-249","250-299","300+"]
    labels = [b for b in order if b in stats]
    values = [stats[b] for b in labels]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(labels, values, color="#1E5631", edgecolor="white", width=0.7)
    ax.set_title("Figure 1: Abstract Word Count Distribution", fontsize=14, fontweight="bold")
    ax.set_xlabel("Word Count Bucket")
    ax.set_ylabel("Number of Abstracts")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))
    plt.tight_layout()
    path = os.path.join(outdir, "fig1_wordcount.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  saved {path}")

def fig2_specialty(stats, outdir):
    items = sorted(stats.items(), key=lambda x: -x[1])
    labels = [i[0] for i in items]
    values = [i[1] for i in items]
    colors = ["#1E5631","#2D7A4A","#4CAF50","#81C784","#A5D6A7",
              "#C8E6C9","#F4A261","#E76F51","#E9C46A","#264653","#2A9D8F"]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.barh(labels[::-1], values[::-1], color=colors[:len(labels)], edgecolor="white")
    ax.set_title("Figure 2: Medical Specialty Distribution", fontsize=14, fontweight="bold")
    ax.set_xlabel("Number of Abstracts")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))
    plt.tight_layout()
    path = os.path.join(outdir, "fig2_specialty.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  saved {path}")

def fig3_year(stats, outdir):
    items = sorted([(k, v) for k, v in stats.items()
                    if k.isdigit() and 1980 <= int(k) <= 2025], key=lambda x: int(x[0]))
    years = [int(x[0]) for x in items]
    counts = [x[1] for x in items]
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.fill_between(years, counts, alpha=0.25, color="#1E5631")
    ax.plot(years, counts, color="#1E5631", linewidth=2)
    ax.set_title("Figure 3: Publications by Year (1980-2025)", fontsize=14, fontweight="bold")
    ax.set_xlabel("Year")
    ax.set_ylabel("Number of Publications")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))
    ax.set_xlim(1980, 2025)
    plt.tight_layout()
    path = os.path.join(outdir, "fig3_year.png")
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"  saved {path}")

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--bucket", required=True)
    p.add_argument("--input-prefix", default="raw/pubmed")
    p.add_argument("--output-prefix", default="processed")
    args = p.parse_args()

    bucket   = args.bucket
    inpath   = f"s3://{bucket}/{args.input_prefix}/*.parquet"
    outbase  = f"s3://{bucket}/{args.output_prefix}"
    figdir   = "/tmp/eda_figures"
    os.makedirs(figdir, exist_ok=True)

    spark = SparkSession.builder \
        .appName("CISC886-PubMed-Preprocessing") \
        .config("spark.sql.shuffle.partitions", "200") \
        .getOrCreate()
    spark.sparkContext.setLogLevel("WARN")

    classify_udf         = F.udf(classify, StringType())
    build_instruction_udf = F.udf(build_instruction, StringType())

    print(f"\n{'='*60}\nSTEP 1: Loading {inpath}\n{'='*60}")
    df = spark.read.parquet(inpath)
    print(f"Raw records: {df.count():,}")

    print("\nSTEP 2: Filtering...")
    df = df.filter(
        F.col("abstract").isNotNull() &
        (F.length("abstract") > 100) &
        (F.length("abstract") < 3000) &
        F.col("abstract").rlike("[A-Za-z]")
    )
    print(f"After filter: {df.count():,}")

    print("\nSTEP 3: Deduplicating...")
    df = df.dropDuplicates(["pmid"])
    print(f"After dedup: {df.count():,}")

    print("\nSTEP 4: Feature engineering...")
    df = df \
        .withColumn("wordcount",   F.size(F.split("abstract", r"\s+"))) \
        .withColumn("specialty",   classify_udf("abstract")) \
        .withColumn("yearclean",   F.regexp_extract("year", r"\d{4}", 0)) \
        .withColumn("instruction", build_instruction_udf("title", "abstract", "specialty"))
    df = df.filter(F.col("instruction").isNotNull())
    total = df.count()
    print(f"Final records: {total:,}")

    print("\nSTEP 5: EDA stats...")
    wc_bucket = (
        F.when(F.col("wordcount") <  50, "<50")
         .when(F.col("wordcount") < 100, "50-99")
         .when(F.col("wordcount") < 150, "100-149")
         .when(F.col("wordcount") < 200, "150-199")
         .when(F.col("wordcount") < 250, "200-249")
         .when(F.col("wordcount") < 300, "250-299")
         .otherwise("300+")
    )
    wc_stats   = {r["wc_bucket"]: r["count"] for r in
                  df.withColumn("wc_bucket", wc_bucket).groupBy("wc_bucket").count().collect()}
    spec_stats = {r["specialty"]: r["count"] for r in df.groupBy("specialty").count().collect()}
    year_stats = {r["yearclean"]: r["count"] for r in df.groupBy("yearclean").count().collect()}

    fig1_wordcount(wc_stats, figdir)
    fig2_specialty(spec_stats, figdir)
    fig3_year(year_stats, figdir)

    s3 = boto3.client("s3")
    for fname in ["fig1_wordcount.png","fig2_specialty.png","fig3_year.png"]:
        s3.upload_file(os.path.join(figdir, fname), bucket,
                       f"{args.output_prefix}/eda/{fname}")
        print(f"  uploaded s3://{bucket}/{args.output_prefix}/eda/{fname}")

    s3.put_object(
        Bucket=bucket,
        Key=f"{args.output_prefix}/eda/stats.json",
        Body=json.dumps({"total": total, "wordcount": wc_stats,
                         "specialty": spec_stats, "year": year_stats}, indent=2).encode()
    )

    print("\nSTEP 6: Train/Val/Test split 80/10/10...")
    cols = ["pmid","title","abstract","specialty","wordcount","yearclean","instruction"]
    train, val, test = df.select(cols).randomSplit([0.80, 0.10, 0.10], seed=42)
    print(f"  train={train.count():,}  val={val.count():,}  test={test.count():,}")

    print("\nSTEP 7: Writing to S3...")
    for name, split in [("train", train), ("val", val), ("test", test)]:
        path = f"{outbase}/{name}"
        split.write.mode("overwrite").parquet(path)
        print(f"  {name} -> {path}")

    spark.stop()
    print(f"\n{'='*60}\nPREPROCESSING COMPLETE\n{'='*60}")

if __name__ == "__main__":
    main()
