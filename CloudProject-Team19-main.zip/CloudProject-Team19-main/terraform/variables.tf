variable "net_id" {
  description = "Your Queens University Net ID (e.g. q1abc)"
  type        = string
}

variable "aws_region" {
  description = "AWS region to deploy all resources"
  type        = string
  default     = "us-east-1"
}

variable "bucket_name" {
  description = "S3 bucket name — must be globally unique"
  type        = string
  # Example: "${var.net_id}-cisc886-bucket"
}

variable "key_pair_name" {
  description = "Name of an existing EC2 Key Pair for SSH access"
  type        = string
}

variable "my_ip" {
  description = "Your public IP for SSH access (get from: curl ifconfig.me)"
  type        = string
  default     = "0.0.0.0/0"  # Restrict to your IP in production!
}
