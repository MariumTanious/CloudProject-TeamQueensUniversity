output "vpc_id" {
  description = "VPC ID — paste this into EMR cluster creation command"
  value       = aws_vpc.main.id
}

output "subnet_id" {
  description = "Public Subnet ID — used for EMR and EC2 placement"
  value       = aws_subnet.public.id
}

output "ec2_sg_id" {
  description = "EC2 Security Group ID — select when launching g4dn.xlarge"
  value       = aws_security_group.ec2_sg.id
}

output "emr_master_sg_id" {
  description = "EMR Master Security Group ID — paste into EMR create command"
  value       = aws_security_group.emr_master_sg.id
}

output "emr_slave_sg_id" {
  description = "EMR Slave Security Group ID — paste into EMR create command"
  value       = aws_security_group.emr_slave_sg.id
}

output "emr_service_role_arn" {
  description = "EMR Service Role ARN — paste into EMR create command"
  value       = aws_iam_role.emr_service_role.arn
}

output "emr_instance_profile_name" {
  description = "EMR EC2 Instance Profile — paste into EMR create command"
  value       = aws_iam_instance_profile.emr_profile.name
}
