terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

# ════════════════════════════════════════════════════════════════════════════════
# VPC
# ════════════════════════════════════════════════════════════════════════════════
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_support   = true
  enable_dns_hostnames = true
  tags = { Name = "${var.net_id}-vpc" }
}

# ── Public Subnet ──────────────────────────────────────────────────────────────
resource "aws_subnet" "public" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = "10.0.1.0/24"
  availability_zone       = "${var.aws_region}a"
  map_public_ip_on_launch = true
  tags = { Name = "${var.net_id}-public-subnet" }
}

# ── Internet Gateway ───────────────────────────────────────────────────────────
resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.main.id
  tags   = { Name = "${var.net_id}-igw" }
}

# ── Route Table ────────────────────────────────────────────────────────────────
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.igw.id
  }
  tags = { Name = "${var.net_id}-public-rt" }
}

resource "aws_route_table_association" "public" {
  subnet_id      = aws_subnet.public.id
  route_table_id = aws_route_table.public.id
}

# ════════════════════════════════════════════════════════════════════════════════
# Security Groups
# ════════════════════════════════════════════════════════════════════════════════

# ── EC2 Security Group (Ollama + OpenWebUI) ────────────────────────────────────
resource "aws_security_group" "ec2_sg" {
  name        = "${var.net_id}-ec2-sg"
  description = "Allow SSH (22), Ollama API (11434), OpenWebUI (8080)"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "SSH - for EC2 access via Git Bash"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.my_ip]
  }
  ingress {
    description = "Ollama REST API - for curl testing and OpenWebUI communication"
    from_port   = 11434
    to_port     = 11434
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  ingress {
    description = "OpenWebUI browser interface"
    from_port   = 8080
    to_port     = 8080
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    description = "Allow all outbound - needed for package downloads and S3 access"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "${var.net_id}-ec2-sg" }
}

# ── EMR Master Security Group ──────────────────────────────────────────────────
resource "aws_security_group" "emr_master_sg" {
  name        = "${var.net_id}-emr-master-sg"
  description = "SSH - for EC2 access via Git Bash"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "SSH to EMR master for job submission and monitoring"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.my_ip]
  }
  egress {
    description = "All outbound - required for S3, HuggingFace, yum packages"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "${var.net_id}-emr-master-sg" }
}

# ── EMR Slave (Core) Security Group ───────────────────────────────────────────
resource "aws_security_group" "emr_slave_sg" {
  name        = "${var.net_id}-emr-slave-sg"
  description = "EMR Core nodes - internal cluster traffic only"
  vpc_id      = aws_vpc.main.id

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "${var.net_id}-emr-slave-sg" }
}

# ── Allow master <-> slave communication (YARN, HDFS) ─────────────────────────
resource "aws_security_group_rule" "master_ingress_from_slave" {
  type                     = "ingress"
  description              = "All traffic from slave nodes to master"
  from_port                = 0
  to_port                  = 65535
  protocol                 = "tcp"
  security_group_id        = aws_security_group.emr_master_sg.id
  source_security_group_id = aws_security_group.emr_slave_sg.id
}

resource "aws_security_group_rule" "slave_ingress_from_master" {
  type                     = "ingress"
  description              = "All traffic from master node to slave nodes"
  from_port                = 0
  to_port                  = 65535
  protocol                 = "tcp"
  security_group_id        = aws_security_group.emr_slave_sg.id
  source_security_group_id = aws_security_group.emr_master_sg.id
}

resource "aws_security_group_rule" "master_self" {
  type              = "ingress"
  description       = "Master self-referential Spark driver to executor"
  from_port         = 0
  to_port           = 65535
  protocol          = "tcp"
  security_group_id = aws_security_group.emr_master_sg.id
  self              = true
}

# ════════════════════════════════════════════════════════════════════════════════
# IAM Roles
# ════════════════════════════════════════════════════════════════════════════════

# ── EMR Service Role ───────────────────────────────────────────────────────────
resource "aws_iam_role" "emr_service_role" {
  name = "${var.net_id}-emr-service-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "elasticmapreduce.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
  tags = { Name = "${var.net_id}-emr-service-role" }
}

resource "aws_iam_role_policy_attachment" "emr_service_policy" {
  role       = aws_iam_role.emr_service_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceRole"
}

# ── EMR EC2 Instance Role ──────────────────────────────────────────────────────
resource "aws_iam_role" "emr_ec2_role" {
  name = "${var.net_id}-emr-ec2-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
  tags = { Name = "${var.net_id}-emr-ec2-role" }
}

resource "aws_iam_role_policy_attachment" "emr_ec2_policy" {
  role       = aws_iam_role.emr_ec2_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceforEC2Role"
}

resource "aws_iam_instance_profile" "emr_profile" {
  name = "${var.net_id}-emr-ec2-profile"
  role = aws_iam_role.emr_ec2_role.name
}
